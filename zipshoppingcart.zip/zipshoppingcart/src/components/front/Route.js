import React from "react";
import Products from "./products";
import { Router } from "react-router-dom";
import Signup from "./signup";
import{Route , Switch} from"react-router-dom";
import Cart from "./cart";
const Routes = ({productItem ,cartItemas,handleAddproduct,handleRemoveproduct,handleCartclear})=>{
    return(
        <div>
            <Switch>
                <Route path="/" exact>
                    <Products productItem={productItem} handleAddproduct={handleAddproduct}></Products>
                </Route>
                <Route path="/Signup" exact>
                    <Signup/>
                </Route>
            <Route path="/Cart" exact>
                <Cart cartItemas={cartItemas} handleAddproduct={handleAddproduct} handleRemoveproduct={handleRemoveproduct} handleCartclear={handleCartclear}></Cart>
            </Route>
            </Switch>
        </div>
    )
}
export default Routes;