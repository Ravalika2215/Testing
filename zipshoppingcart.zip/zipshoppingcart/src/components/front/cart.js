import React from "react";
import"./cart.css"
const Cart=({cartItemas,handleAddproduct,handleRemoveproduct,handleCartclear})=>{
    const totalprice = cartItemas.reduce((price, item)=> price + item.qunatity * item.price, 0)
    return(
        <div className="cart-items">
            <div className="cart-items-header">

                Cart items
            </div>
            <div className="clear-cart" >
            {
                cartItemas.length>1 &&(<i class="far fa-trash-alt" onClick={()=>handleCartclear()} ></i>)
            }
            {/* <i class="fas fa-edit" onClick={()=>handleCartclear()} ></i> */}

            </div>
            {cartItemas.length === 0 &&(
            <div className="cart-item-empty">No items are added...</div>)}
            <div>
                {cartItemas.map((items)=>(
                <div key={items.id} className="cart-item-list">
                    <img src={items.Image} className="cart-item-images"></img>
                    <div className="cart-item-Name">{items.Name}</div>
                    <div className="cart-item-function">
                        <button className="cart-item-add" onClick={()=>handleAddproduct(items)}>+</button>
                        <button className="cart-item-remove" onClick={()=>handleRemoveproduct(items)}>-</button>
                    </div>
                    <div className="cart-item-price">
                        {items.qunatity} * ${items.price}
                    </div>
                   
                  
                </div>
                
                ))}
            </div>
            <div className="cart-item-totalprice-Name">
                        Total price
                    <div className="cart-item-totalprice">${totalprice}</div>
                    </div>
        </div>
    )
}
export default Cart;